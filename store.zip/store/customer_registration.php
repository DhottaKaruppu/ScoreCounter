<?php
if (isset($_GET["register"])) {
	
	?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>E-commerce Website</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
<header class="header-content">
	<div class="top-bar">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<div class="top-bar-left">
						<ul class="top-bar-contact list-line">
							<li class="phone">
								<i class="fa fa-phone phone-color"></i>
								<span>0452256565</span>
							</li>
							<li class="email">
							  <i class="fa fa-envelope-o phone-color"></i>
								<span>Email@gmail.com</span>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6">
                   <div class="top-bar-right">
                      <ul class="list-inline">
                         <li class="hidden-xs">              
                            <a href="/pages/contact-us" title="Store Location">
                               <i class="fa fa-map-marker icon"></i><span>Store Location</span>
                            </a>
                        </li>
                        <li class="hidden-xs">            
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Your Order"><i class="fa fa-truck icon"></i>Your Order <span class="badge">0</span></a>
                           <div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success no-border-panel">
							<div class="panel-heading panel-color">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in $.</div>
								</div>
							</div>
							<div class="panel-body">
								<div id="cart_product">
								
								</div>
							</div>
							<!-- <div class="panel-footer"></div> -->
						</div>
					</div>
                       </li>
                      <li class="currency dropdown-parent uppercase currency-block">
                           <a class="currency_wrapper dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                             <span class="currency_code"></i>USD</span>
                             <i class="fa fa-angle-down"></i>
                          </a> 
                            <ul class="currencies dropdown-menu text-left">
                               <li class="currency-USD active">
                                  <a href="javascript:;"><i class="flag-usd"></i>USD</a>
                                  <input type="hidden" value="USD">
                               </li>
                               <li class="currency-EUR">
                                <a href="javascript:;"><i class="flag-eur"></i>EUR</a>
                                <input type="hidden" value="EUR">
                              </li> 
                              <li class="currency-GBP">
                                 <a href="javascript:;"><i class="flag-gbp"></i>GBP</a>
                                 <input type="hidden" value="GBP">
                              </li>
                           </ul>
                         <select class="currencies_src hide" name="currencies">  
                             <option value="USD" selected="selected">USD</option>
                             <option value="EUR">EUR</option>
                             <option value="GBP">GBP</option>   
                        </select>
                    </li>
                <li>         
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Register"><i class="icon icon-user"></i>Sign In</a>
                    <span class="customer-or">or</span>
                  <a  href="customer_registration.php?register=1" title="">Register</a>
                  <ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="#" style="color:white; list-style:none;">Forgotten Password</a><input type="submit" class="btn btn-success" style="float:right;">
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
               </li>
             </ul>
			</div>
		</div>
	</div>
   </div>
 </div>


 <!--main-header-->
 <div class="middle-header">
 	<div class="container">
 		<div class="row">
 			<div class="row-wrapper">
 				<div class="header-logo col-md-3">
 					<a href="" class="logo-site">
 						<h2 class="logo">E-commerce Web</h2>
 					</a>
 				</div>
 				<div class="col-xs-12 col-md-6 top-search-holder col-sm-6">
 					<div class="searchbox">
 						<form id="search" class="navbar-form search">
 							<input type="hidden" name="type" value="product">
 							<input id="bc-product-search" type="text" name="q" class="form-control" placeholder="Search for item" autocomplete="off">
 							<button type="submit" class="search-icon btn-default"><i class="fa fa-search"></i></button>
 						</form>
 					</div>
 				</div>
 				<div class="col-xs-12 col-md-3 top-cart-row col-sm-6">
 					<div class="top-cart-row-container">
 						<div class="wishlist-checkout-holder">
 							<div class="compare-target">
 								<a href="javascript:;" class="num-items-in-compare show-compare" title="Compare">
                                   <span class="icon fa fa-shopping-cart"></span>
                                </a>
 							</div>
 							<div class="header-mobile-icon wishlist-target">
                              <a href="javascript:;" class="num-items-in-wishlist show-wishlist" title="Wishlist">
                                <span class="wishlist-icon"><i class="icon fa fa-question-circle"></i></span>
                             </a>
                           </div>
 						</div>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </div>
 <!--end-main-header-->
 <!--menubar-->
 <nav class="navbar navbar-default " >
  <div class="container">
    <!-- <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div> -->
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">HOME</a></li>
      <li><a href="#" class="dropdown-toggle" data-toggle="dropdown" >ORGANIC PRODUCTS</a>
            <ul class="dropdown-menu" id="get_subcategories">
				<li><a href="#" >1</a></li>
					<li><a href="#" >1</a></li>
						<li><a href="#" >1</a></li>
			</ul>
      </li>
      <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">NATURAL PRODUCTS</a>
        <ul class="dropdown-menu" id="get_naturalproducts">
				<li><a href="#" >1</a></li>
					<li><a href="#" >1</a></li>
						<li><a href="#" >1</a></li>
			</ul>
      </li>
      <li><a href="#"> MEN</a></li>
      <li><a href="#"> WOMEN</a></li>
        <li><a href="#"> LEATHERS & ACCESSORIES</a></li>
    </ul>

  </div>
</nav>
 <!--menubar end-->
</header>


<!--====================register section with full Backgrounc==================-->

<section class="signup-bg">
	<div class="reg-header">
		<h1>Re<span>g</span>is<span>t</span>r<span>a</span>tio<span>n</span></h1>

	    <div class="main-form">
	    	<div class="sub-main">
	    		<h2>	</h2>
	    		<form id="signup_form" onsubmit="return false">
	    			<div class="row">
	    			<div class="col-md-6">
	    					<label for="f_name">First Name</label>
	    			        <div class="form-in">
	    				      <input type="text" id="f_name" name="f_name" class="in-text">
	    			       </div>
	    			</div>	
	    		    <div class="col-md-6">
	    		    	<label for="l_name">Last Name</label>
	    			   <div class="form-in">
	    				  <input type="text" id="l_name" name="l_name" class="in-text">
	    			   </div>
	    		    </div>
	    			
	    			<div class="col-md-6">
	    				<label for="email">Email</label>
	    			    <div class="form-in">
	    					<input type="text" id="email" name="email" class="in-text">
	    			   </div>
	    			</div>
	    			<div class="col-md-6">
	    				<label for="password">Password</label>
	    			     <div class="form-in">
	    				  <input type="password" id="password" name="password" class="in-text">
	    			    </div>
	    			</div>
	    			<div class="col-md-6">
	    					<label for="repassword">Re-Password</label>
	    			     <div class="form-in">
	    				  <input type="password" id="repassword" name="repassword" class="in-text">
	    			    </div>
	    			</div>
	    			<div class="col-md-6">
	    				<label for="mobile">Mobile</label>
	    			     <div class="form-in">
	    				   <input type="text" id="mobile" name="mobile" class="in-text">
	    			    </div>
	    			</div>
	    			<div class="col-md-6">
	    				<label for="address1">Address1</label>
	    			      <div class="form-in">
	    				    <input type="text" id="address1" name="address1" class="in-text">
	    			      </div>
	    			</div>
	    			<div class="col-md-6">	
	    			    <label for="address2">Address2</label>
	    			   <div class="form-in">
	    				 <input type="text" id="address2" name="address2" class="in-text">
	    			</div>
	    			</div>	
	    			  <div class="col-md-12">
					    <input style="width:100%;" value="Sign Up" type="submit" name="signup_button"class="btn btn-success btn-lg">
					 </div>
					 <div class="col-md-8" id="signup_msg"></div>
	    		</div>
	    		</form>
	    	</div>
	    </div>
	</div>

</section>







<!--==============================end register =========================-->


<!-- 	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand">E-Commerce Website</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
		</div>
	</div> -->
	<!-- <p><br/></p>
	<p><br/></p>
	<p><br/></p> -->
<!-- 	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				Alert from signup form
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Customer SignUp Form</div>
					<div class="panel-body">
					
					<form id="signup_form" onsubmit="return false">
						<div class="row">
							<div class="col-md-6">
								<label for="f_name">First Name</label>
								<input type="text" id="f_name" name="f_name" class="form-control">
							</div>
							<div class="col-md-6">
								<label for="f_name">Last Name</label>
								<input type="text" id="l_name" name="l_name"class="form-control">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="email">Email</label>
								<input type="text" id="email" name="email"class="form-control">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="password">password</label>
								<input type="password" id="password" name="password"class="form-control">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="repassword">Re-enter Password</label>
								<input type="password" id="repassword" name="repassword"class="form-control">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="mobile">Mobile</label>
								<input type="text" id="mobile" name="mobile"class="form-control">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="address1">Address Line 1</label>
								<input type="text" id="address1" name="address1"class="form-control">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="address2">Address Line 2</label>
								<input type="text" id="address2" name="address2"class="form-control">
							</div>
						</div>
						<p><br/></p>
						<div class="row">
							<div class="col-md-12">
								<input style="width:100%;" value="Sign Up" type="submit" name="signup_button"class="btn btn-success btn-lg">
							</div>
						</div>
						
					</div>
					</form>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div> -->
</body>
</html>
	<?php
}



?>






















