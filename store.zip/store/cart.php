<?php


?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>E-commerce Website</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css"/>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>

<!--=================menu=======================-->
<header class="header-content">
	<div class="top-bar">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<div class="top-bar-left">
						<ul class="top-bar-contact list-line">
							<li class="phone">
								<i class="fa fa-phone phone-color"></i>
								<span>0452256565</span>
							</li>
							<li class="email">
							  <i class="fa fa-envelope-o phone-color"></i>
								<span>Email@gmail.com</span>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6">
                   <div class="top-bar-right">
                      <ul class="list-inline">
                         <li class="hidden-xs">              
                            <a href="/pages/contact-us" title="Store Location">
                               <i class="fa fa-map-marker icon"></i><span>Store Location</span>
                            </a>
                        </li>
                        <li class="hidden-xs">            
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Your Order"><i class="fa fa-truck icon"></i>Your Order <span class="badge">0</span></a>
                           <div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success no-border-panel">
							<div class="panel-heading panel-color">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in $.</div>
								</div>
							</div>
							<div class="panel-body">
								<div id="cart_product">
								
								</div>
							</div>
							<!-- <div class="panel-footer"></div> -->
						</div>
					</div>
                       </li>
                      <li class="currency dropdown-parent uppercase currency-block">
                           <a class="currency_wrapper dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                             <span class="currency_code"></i>USD</span>
                             <i class="fa fa-angle-down"></i>
                          </a> 
                            <ul class="currencies dropdown-menu text-left">
                               <li class="currency-USD active">
                                  <a href="javascript:;"><i class="flag-usd"></i>USD</a>
                                  <input type="hidden" value="USD">
                               </li>
                               <li class="currency-EUR">
                                <a href="javascript:;"><i class="flag-eur"></i>EUR</a>
                                <input type="hidden" value="EUR">
                              </li> 
                              <li class="currency-GBP">
                                 <a href="javascript:;"><i class="flag-gbp"></i>GBP</a>
                                 <input type="hidden" value="GBP">
                              </li>
                           </ul>
                         <select class="currencies_src hide" name="currencies">  
                             <option value="USD" selected="selected">USD</option>
                             <option value="EUR">EUR</option>
                             <option value="GBP">GBP</option>   
                        </select>
                    </li>
     
         <!--       <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span><?php echo "Hi,".$_SESSION["name"]; ?></a>
					<ul class="dropdown-menu">
						<li><a href="cart.php" style="text-decoration:none; color:blue;"><span class="glyphicon glyphicon-shopping-cart">Cart</a></li>
						<li class="divider"></li>
						<li><a href="customer_order.php" style="text-decoration:none; color:blue;">Orders</a></li>
						<li class="divider"></li>
						<li><a href="" style="text-decoration:none; color:blue;">Chnage Password</a></li>
						<li class="divider"></li>
						<li><a href="logout.php" style="text-decoration:none; color:blue;">Logout</a></li>
					</ul>
				</li> -->
             </ul>
			</div>
		</div>
	</div>
   </div>
 </div>


 <!--main-header-->
 <div class="middle-header">
 	<div class="container">
 		<div class="row">
 			<div class="row-wrapper">
 				<div class="header-logo col-md-3">
 					<a href="" class="logo-site">
 						<h2 class="logo">E-commerce Web</h2>
 					</a>
 				</div>
 				<div class="col-xs-12 col-md-6 top-search-holder col-sm-6">
 					<div class="searchbox">
 						<form id="search" class="navbar-form search">
 							<input type="hidden" name="type" value="product">
 							<input id="bc-product-search" type="text" name="q" class="form-control" placeholder="Search for item" autocomplete="off">
 							<button type="submit" class="search-icon btn-default"><i class="fa fa-search"></i></button>
 						</form>
 					</div>
 				</div>
 				<div class="col-xs-12 col-md-3 top-cart-row col-sm-6">
 					<div class="top-cart-row-container">
 						<div class="wishlist-checkout-holder">
 							<div class="compare-target">
 								<a href="javascript:;" class="num-items-in-compare show-compare" title="Compare">
                                   <span class="icon fa fa-shopping-cart"></span>
                                </a>
 							</div>
 							<div class="header-mobile-icon wishlist-target">
                              <a href="javascript:;" class="num-items-in-wishlist show-wishlist" title="Wishlist">
                                <span class="wishlist-icon"><i class="icon fa fa-question-circle"></i></span>
                             </a>
                           </div>
 						</div>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </div>
 <!--end-main-header-->
 <!--menubar-->
 <nav class="navbar navbar-default " >
  <div class="container">
    <!-- <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div> -->
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">HOME</a></li>
      <li><a href="#" class="dropdown-toggle" data-toggle="dropdown" >ORGANIC PRODUCTS</a>
            <ul class="dropdown-menu" id="get_subcategories">
				<li><a href="#" >1</a></li>
					<li><a href="#" >1</a></li>
						<li><a href="#" >1</a></li>
			</ul>
      </li>
      <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">NATURAL PRODUCTS</a>
        <ul class="dropdown-menu" id="get_naturalproducts">
				<li><a href="#" >1</a></li>
					<li><a href="#" >1</a></li>
						<li><a href="#" >1</a></li>
			</ul>
      </li>
      <li><a href="#"> MEN</a></li>
      <li><a href="#"> WOMEN</a></li>
        <li><a href="#"> LEATHERS & ACCESSORIES</a></li>
    </ul>

  </div>
</nav>
 <!--menubar end-->
</header>
<!--=================end========================-->
















<!-- 	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">E-Commerce Website</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
		</div>
	</div>
	</div> -->
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="cart_msg">
				<!--Cart Message--> 
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Cart Checkout</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-2 col-xs-2"><b>Action</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Image</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Name</b></div>
							<div class="col-md-2 col-xs-2"><b>Quantity</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Price</b></div>
							<div class="col-md-2 col-xs-2"><b>Price in $</b></div>
						</div>
						<div id="cart_checkout"></div>
						<!--<div class="row">
							<div class="col-md-2">
								<div class="btn-group">
									<a href="#" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
									<a href="" class="btn btn-primary"><span class="glyphicon glyphicon-ok-sign"></span></a>
								</div>
							</div>
							<div class="col-md-2"><img src='product_images/imges.jpg'></div>
							<div class="col-md-2">Product Name</div>
							<div class="col-md-2"><input type='text' class='form-control' value='1' ></div>
							<div class="col-md-2"><input type='text' class='form-control' value='5000' disabled></div>
							<div class="col-md-2"><input type='text' class='form-control' value='5000' disabled></div>
						</div> -->
						<!--<div class="row">
							<div class="col-md-8"></div>
							<div class="col-md-4">
								<b>Total $500000</b>
							</div> -->
						</div> 
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
			
		</div>
</body>	
</html>
















		