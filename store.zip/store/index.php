<?php
session_start();
if(isset($_SESSION["uid"])){
	header("location:profile.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ecommerce Website</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
		<style></style>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
<header class="header-content">
	<div class="top-bar">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<div class="top-bar-left">
						<ul class="top-bar-contact list-line">
							<li class="phone">
								<i class="fa fa-phone phone-color"></i>
								<span>0452256565</span>
							</li>
							<li class="email">
							  <i class="fa fa-envelope-o phone-color"></i>
								<span>Email@gmail.com</span>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6">
                   <div class="top-bar-right">
                      <ul class="list-inline">
                         <li class="hidden-xs">              
                            <a href="/pages/contact-us" title="Store Location">
                               <i class="fa fa-map-marker icon"></i><span>Store Location</span>
                            </a>
                        </li>
                        <li class="hidden-xs">            
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Your Order"><i class="fa fa-truck icon"></i>Your Order <span class="badge">0</span></a>
                           <div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success no-border-panel">
							<div class="panel-heading panel-color">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in $.</div>
								</div>
							</div>
							<div class="panel-body">
								<div id="cart_product">
								
								</div>
							</div>
							<!-- <div class="panel-footer"></div> -->
						</div>
					</div>
                       </li>
                      <li class="currency dropdown-parent uppercase currency-block">
                           <a class="currency_wrapper dropdown-toggle" href="javascript:;" data-toggle="dropdown">
                             <span class="currency_code"></i>USD</span>
                             <i class="fa fa-angle-down"></i>
                          </a> 
                            <ul class="currencies dropdown-menu text-left">
                               <li class="currency-USD active">
                                  <a href="javascript:;"><i class="flag-usd"></i>USD</a>
                                  <input type="hidden" value="USD">
                               </li>
                               <li class="currency-EUR">
                                <a href="javascript:;"><i class="flag-eur"></i>EUR</a>
                                <input type="hidden" value="EUR">
                              </li> 
                              <li class="currency-GBP">
                                 <a href="javascript:;"><i class="flag-gbp"></i>GBP</a>
                                 <input type="hidden" value="GBP">
                              </li>
                           </ul>
                         <select class="currencies_src hide" name="currencies">  
                             <option value="USD" selected="selected">USD</option>
                             <option value="EUR">EUR</option>
                             <option value="GBP">GBP</option>   
                        </select>
                    </li>
                <li>         
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Register"><i class="icon icon-user"></i>Sign In</a>
                    <span class="customer-or">or</span>
                  <a  href="customer_registration.php?register=1" title="">Register</a>
                  <ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="#" style="color:white; list-style:none;">Forgotten Password</a><input type="submit" class="btn btn-success" style="float:right;">
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
               </li>
             </ul>
			</div>
		</div>
	</div>
   </div>
 </div>


 <!--main-header-->
 <div class="middle-header">
 	<div class="container">
 		<div class="row">
 			<div class="row-wrapper">
 				<div class="header-logo col-md-3">
 					<a href="" class="logo-site">
 						<h2 class="logo">E-commerce Web</h2>
 					</a>
 				</div>
 				<div class="col-xs-12 col-md-6 top-search-holder col-sm-6">
 					<div class="searchbox">
 						<form id="search" class="navbar-form search">
 							<input type="hidden" name="type" value="product">
 							<input id="bc-product-search" type="text" name="q" class="form-control" placeholder="Search for item" autocomplete="off">
 							<button type="submit" class="search-icon btn-default"><i class="fa fa-search"></i></button>
 						</form>
 					</div>
 				</div>
 				<div class="col-xs-12 col-md-3 top-cart-row col-sm-6">
 					<div class="top-cart-row-container">
 						<div class="wishlist-checkout-holder">
 							<div class="compare-target">
 								<a href="javascript:;" class="num-items-in-compare show-compare" title="Compare">
                                   <span class="icon fa fa-shopping-cart"></span>
                                </a>
 							</div>
 							<div class="header-mobile-icon wishlist-target">
                              <a href="javascript:;" class="num-items-in-wishlist show-wishlist" title="Wishlist">
                                <span class="wishlist-icon"><i class="icon fa fa-question-circle"></i></span>
                             </a>
                           </div>
 						</div>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </div>
 <!--end-main-header-->
 <!--menubar-->
 <nav class="navbar navbar-default " >
  <div class="container">
    <!-- <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div> -->
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">HOME</a></li>
      <li><a href="#">ORGANIC PRODUCTS</a></li>
      <li><a href="#">NATURAL PRODUCTS</a></li>
      <li><a href="#"> MEN</a></li>
      <li><a href="#"> WOMEN</a></li>
        <li><a href="#"> LEATHERS & ACCESSORIES</a></li>
    </ul>

  </div>
</nav>
 <!--menubar end-->
</header>

<!--main-content-->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="product_images/slider.jpg" alt="Los Angeles">
    </div>

    <div class="item">
      <img src="product_images/slider1.jpg" alt="Chicago">
    </div>

    <div class="item">
      <img src="product_images/slider3.jpg" alt="New York">
    </div>
  </div>
</div>
<!--end main-content-->

<div class="home-top-banner">
	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-xs-12">
				<div class="banner-item">
					
				</div>
			</div>
			<div class="col-sm-4 col-xs-12">
				<div class="banner-item">
					
				</div>
			</div>
			<div class="col-sm-4 col-xs-12">
				<div class="banner-item">
					
				</div>
			</div>
		</div>
	</div>
</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-2 col-xs-12">
				<div id="get_category">
				</div>
				<div id="get_brand">
				</div>
			</div>
			<div class="col-md-8 col-xs-12">
				<div class="row">
					<div class="col-md-12 col-xs-12" id="product_msg">
					</div>
				</div>
				<div class="panel panel-info">
					<div class="panel-heading">Products</div>
					<div class="panel-body">
						<div id="get_product">
							<!--Here we get product jquery Ajax Request-->
						</div>
						
					</div>
					<div class="panel-footer">&copy; 2016</div>
				</div>
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
</body>
</html>












<!-- 	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">E-Commmerce Website</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
			<form class="navbar-form navbar-left">
		        <div class="form-group">
		          <input type="text" class="form-control" placeholder="Search" id="search">
		        </div>
		        <button type="submit" class="btn btn-primary" id="search_btn"><span class="glyphicon glyphicon-search"></span></button>
		     </form>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span>Cart<span class="badge">0</span></a>
					<div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success">
							<div class="panel-heading">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in $.</div>
								</div>
							</div>
							<div class="panel-body">
								<div id="cart_product">
								
								</div>
							</div>
							<div class="panel-footer"></div>
						</div>
					</div>
				</li>
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>SignIn</a>
					<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="#" style="color:white; list-style:none;">Forgotten Password</a><input type="submit" class="btn btn-success" style="float:right;">
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div> -->	



































